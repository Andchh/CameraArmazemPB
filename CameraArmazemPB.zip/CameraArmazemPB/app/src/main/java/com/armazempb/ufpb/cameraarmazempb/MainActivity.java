package com.armazempb.ufpb.cameraarmazempb;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

public class MainActivity extends Activity {

    private ImageView myImageView;
    private static final int REQUEST_IMAGE_CAPTURE = 101;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myImageView = findViewById(R.id.CameraImage);
        //getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,   //fullscreen
        //        WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    public void takePicture(View view) {

        Intent imageTakeIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if(imageTakeIntent.resolveActivity(getPackageManager()) != null){ //check if there's any aplication who can handle the intent
            startActivityForResult(imageTakeIntent, REQUEST_IMAGE_CAPTURE);
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) { //for retrieve the data
        if(requestCode==REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras(); //pega o intent
            Bitmap ImageBitmap = (Bitmap)extras.get("data");  //salva e converte com bitmap
            myImageView.setImageBitmap(ImageBitmap);  //mostra no imageview da tela
        }

    }
}
